﻿namespace DrawFiguresForAutoCad
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.PointCircArcAndVolBox = new System.Windows.Forms.PictureBox();
            this.PointCircArcBox = new System.Windows.Forms.PictureBox();
            this.CircArcBox = new System.Windows.Forms.PictureBox();
            this.CylinderBox = new System.Windows.Forms.PictureBox();
            this.CubeBox = new System.Windows.Forms.PictureBox();
            this.SphereBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.showFigure = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PointCircArcAndVolBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PointCircArcBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CircArcBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CylinderBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CubeBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SphereBox)).BeginInit();
            this.SuspendLayout();
            // 
            // PointCircArcAndVolBox
            // 
            this.PointCircArcAndVolBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PointCircArcAndVolBox.Image = global::DrawFiguresForAutoCad.Properties.Resources.CircArcByPAndV;
            this.PointCircArcAndVolBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("PointCircArcAndVolBox.InitialImage")));
            this.PointCircArcAndVolBox.Location = new System.Drawing.Point(638, 312);
            this.PointCircArcAndVolBox.Name = "PointCircArcAndVolBox";
            this.PointCircArcAndVolBox.Size = new System.Drawing.Size(227, 213);
            this.PointCircArcAndVolBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PointCircArcAndVolBox.TabIndex = 5;
            this.PointCircArcAndVolBox.TabStop = false;
            this.PointCircArcAndVolBox.Click += new System.EventHandler(this.PointCircArcAndVolBox_Click);
            // 
            // PointCircArcBox
            // 
            this.PointCircArcBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PointCircArcBox.Image = global::DrawFiguresForAutoCad.Properties.Resources.CircArcByP;
            this.PointCircArcBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("PointCircArcBox.InitialImage")));
            this.PointCircArcBox.Location = new System.Drawing.Point(337, 312);
            this.PointCircArcBox.Name = "PointCircArcBox";
            this.PointCircArcBox.Size = new System.Drawing.Size(227, 213);
            this.PointCircArcBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PointCircArcBox.TabIndex = 4;
            this.PointCircArcBox.TabStop = false;
            this.PointCircArcBox.Click += new System.EventHandler(this.PointCircArcBox_Click);
            // 
            // CircArcBox
            // 
            this.CircArcBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CircArcBox.Image = global::DrawFiguresForAutoCad.Properties.Resources.CircularArc;
            this.CircArcBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("CircArcBox.InitialImage")));
            this.CircArcBox.Location = new System.Drawing.Point(48, 312);
            this.CircArcBox.Name = "CircArcBox";
            this.CircArcBox.Size = new System.Drawing.Size(227, 213);
            this.CircArcBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CircArcBox.TabIndex = 3;
            this.CircArcBox.TabStop = false;
            this.CircArcBox.Click += new System.EventHandler(this.CircArcBox_Click);
            // 
            // CylinderBox
            // 
            this.CylinderBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CylinderBox.Image = global::DrawFiguresForAutoCad.Properties.Resources.cylinder;
            this.CylinderBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("CylinderBox.InitialImage")));
            this.CylinderBox.Location = new System.Drawing.Point(638, 24);
            this.CylinderBox.Name = "CylinderBox";
            this.CylinderBox.Size = new System.Drawing.Size(227, 213);
            this.CylinderBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CylinderBox.TabIndex = 2;
            this.CylinderBox.TabStop = false;
            this.CylinderBox.Click += new System.EventHandler(this.CylinderBox_Click);
            // 
            // CubeBox
            // 
            this.CubeBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CubeBox.Image = global::DrawFiguresForAutoCad.Properties.Resources.cube;
            this.CubeBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("CubeBox.InitialImage")));
            this.CubeBox.Location = new System.Drawing.Point(337, 24);
            this.CubeBox.Name = "CubeBox";
            this.CubeBox.Size = new System.Drawing.Size(227, 213);
            this.CubeBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CubeBox.TabIndex = 1;
            this.CubeBox.TabStop = false;
            this.CubeBox.Click += new System.EventHandler(this.CubeBox_Click);
            // 
            // SphereBox
            // 
            this.SphereBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SphereBox.Image = global::DrawFiguresForAutoCad.Properties.Resources.Sphere;
            this.SphereBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("SphereBox.InitialImage")));
            this.SphereBox.Location = new System.Drawing.Point(48, 24);
            this.SphereBox.Name = "SphereBox";
            this.SphereBox.Size = new System.Drawing.Size(227, 213);
            this.SphereBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SphereBox.TabIndex = 0;
            this.SphereBox.TabStop = false;
            this.SphereBox.Click += new System.EventHandler(this.SphereBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(99, 250);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 36);
            this.label1.TabIndex = 6;
            this.label1.Text = "Сфера";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(411, 250);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 36);
            this.label2.TabIndex = 7;
            this.label2.Text = "Куб";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(684, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 36);
            this.label3.TabIndex = 8;
            this.label3.Text = "Цилиндр";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(75, 542);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "Выработка";
            // 
            // label5
            // 
            this.label5.AllowDrop = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(299, 515);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(305, 113);
            this.label5.TabIndex = 10;
            this.label5.Text = "Выработка по точкам";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(631, 528);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(245, 86);
            this.label6.TabIndex = 11;
            this.label6.Text = "Объем выработки";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showFigure
            // 
            this.showFigure.BackColor = System.Drawing.Color.LightGray;
            this.showFigure.Cursor = System.Windows.Forms.Cursors.Hand;
            this.showFigure.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.showFigure.Location = new System.Drawing.Point(337, 631);
            this.showFigure.Name = "showFigure";
            this.showFigure.Size = new System.Drawing.Size(227, 92);
            this.showFigure.TabIndex = 12;
            this.showFigure.Text = "Закрыть и нарисовать";
            this.showFigure.UseVisualStyleBackColor = false;
            this.showFigure.Click += new System.EventHandler(this.showFigure_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(40)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(932, 748);
            this.Controls.Add(this.showFigure);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PointCircArcAndVolBox);
            this.Controls.Add(this.PointCircArcBox);
            this.Controls.Add(this.CircArcBox);
            this.Controls.Add(this.CylinderBox);
            this.Controls.Add(this.CubeBox);
            this.Controls.Add(this.SphereBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainForm";
            this.Text = "Drawings";
            ((System.ComponentModel.ISupportInitialize)(this.PointCircArcAndVolBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PointCircArcBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CircArcBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CylinderBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CubeBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SphereBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox SphereBox;
        private System.Windows.Forms.PictureBox CubeBox;
        private System.Windows.Forms.PictureBox CylinderBox;
        private System.Windows.Forms.PictureBox CircArcBox;
        private System.Windows.Forms.PictureBox PointCircArcBox;
        private System.Windows.Forms.PictureBox PointCircArcAndVolBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button showFigure;
    }
}