﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.PlottingServices;
using Autodesk.AutoCAD.Runtime;
namespace DrawFiguresForAutoCad
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        
        private void SphereBox_Click(object sender, EventArgs e)
        {
            Sphere sphere = new Sphere();
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(sphere);
        }

        private void CubeBox_Click(object sender, EventArgs e)
        {
            Cube cube = new Cube();
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(cube);
        }

        private void CylinderBox_Click(object sender, EventArgs e)
        {
            Cylinder cylinder = new Cylinder();
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(cylinder);
        }

        private void CircArcBox_Click(object sender, EventArgs e)
        {
            CircularArc circular = new CircularArc();
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(circular);
        }

        private void PointCircArcBox_Click(object sender, EventArgs e)
        {
            CirArcByPoints circular = new CirArcByPoints();
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(circular);
        }

        private void PointCircArcAndVolBox_Click(object sender, EventArgs e)
        {
            
            CirArcAndVol form = new CirArcAndVol();
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(form);
        }

        private void showFigure_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
