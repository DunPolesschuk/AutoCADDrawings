﻿using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrawFiguresForAutoCad
{
    public partial class CircularArc : Form
    {
        public CircularArc()
        {
            InitializeComponent();
        }
        public Autodesk.AutoCAD.DatabaseServices.Region ArcFig(Point3d center, double width, double radius, double height)
        {
            Point3d center2 = new Point3d(center[0] - width / 2 + radius, center[1] + height - radius, center[2]);
            Point3d center3 = new Point3d(center[0] + width / 2 - radius, center[1] + height - radius, center[2]);

            Point3d vertex1 = new Point3d(center[0] - width / 2, center[1], center[2]);
            Point3d vertex2 = new Point3d(center[0] - width / 2, center[1] + height - radius, center[2]);

            Point3d vertex3 = new Point3d(center[0] - width / 2 + radius, center[1] + height, center[2]);
            Point3d vertex4 = new Point3d(center[0] + width / 2 - radius, center[1] + height, center[2]);

            Point3d vertex5 = new Point3d(center[0] + width / 2, center[1], center[2]);
            Point3d vertex6 = new Point3d(center[0] + width / 2, center[1] + height - radius, center[2]);

            Arc semicircle1 = new Arc(center2, radius, Math.PI / 2, Math.PI);
            Arc semicircle2 = new Arc(center3, radius, 0, Math.PI / 2);

            Line line1 = new Line(vertex1, vertex2);
            Line line2 = new Line(vertex3, vertex4);
            Line line3 = new Line(vertex5, vertex6);
            Line line4 = new Line(vertex1, vertex5);

            // Создание региона из 2D-фигуры
            DBObjectCollection col = new DBObjectCollection();
            col.Add(line1);
            col.Add(line2);
            col.Add(line3);
            col.Add(line4);
            col.Add(semicircle1);
            col.Add(semicircle2);
            DBObjectCollection regions = Autodesk.AutoCAD.DatabaseServices.Region.CreateFromCurves(col);



            Autodesk.AutoCAD.DatabaseServices.Region region = regions[0] as Autodesk.AutoCAD.DatabaseServices.Region;
            return region;
        }
        public void CreateCircleArc3D(double width, double height, double radius, Point3d center, double extrusionHeight, Vector3d direction, double AngleValue)
        {

            // Получение текущего документа AutoCAD
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            var db = doc.Database;
            Editor ed = doc.Editor;

            
            


            // Создание круглой арки
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                var bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                var btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;



                // Экструзия региона
                Solid3d solid = new Solid3d();
                solid.Extrude(ArcFig(center, width, radius, height), extrusionHeight, 0.0);
                
                // Применение матрицы трансформации
                Matrix3d rotation = Matrix3d.Rotation(AngleValue / 57.296, direction, center);

                solid.TransformBy(rotation);
                solid.TransformBy(Matrix3d.Displacement(new Vector3d(0, extrusionHeight, 0)));
                btr.AppendEntity(solid);
                tr.AddNewlyCreatedDBObject(solid, true);

                tr.Commit();
            }
        }

        private void CreateBut_Click(object sender, EventArgs e)
        {
            double x, y, z, width, length, height, radius, vx, vy, vz, angle;
            if (double.TryParse(XBox.Text, out x) && double.TryParse(YBox.Text, out y) && double.TryParse(ZBox.Text, out z) && double.TryParse(radiusBox.Text, out radius) &&
                double.TryParse(lengthBox.Text, out length) && double.TryParse(heightBox.Text, out height) && double.TryParse(widthBox.Text, out width) && double.TryParse(angleBox.Text, out angle) &&
                double.TryParse(VXBox.Text, out vx) && double.TryParse(VYBox.Text, out vy) && double.TryParse(VZBox.Text, out vz))
            {
                if (width <= 0 || height <= 0 || radius < 0 || length <= 0)
                { 
                    MessageBox.Show("Значения высоты, длины, ширины и радиуса должны быть положительными!"); 
                    lengthBox.Clear();
                    widthBox.Clear();
                    heightBox.Clear();
                    radiusBox.Clear();
                }
                else
                {
                    Point3d center = new Point3d(x, y, z);
                    Vector3d direction = new Vector3d(vx, vy, vz);

                    CreateCircleArc3D(width, length, radius, center, height, direction, angle);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }
    }
}
