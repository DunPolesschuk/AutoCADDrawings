﻿using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.AutoCAD.Colors;
using System.Windows.Forms;
using Region = Autodesk.AutoCAD.DatabaseServices.Region;
using Color = Autodesk.AutoCAD.Colors.Color;
using static Autodesk.AutoCAD.Internal.Forms.ExListView;
using System.Windows.Media.Media3D;

namespace DrawFiguresForAutoCad
{
    public partial class CirArcAndVol : Form
    {
        List<Point3d> points;
        List<double> heights;
        List<int> parts;
        int countofboxes = 0;
        int countofpoints = 0;
        int countofclick = 0;
        public Region ArcFig(Point3d center, double width, double radius, double height)
        {
            Point3d center2 = new Point3d(center[0] - width / 2 + radius, center[1] + height - radius, center[2]);
            Point3d center3 = new Point3d(center[0] + width / 2 - radius, center[1] + height - radius, center[2]);

            Point3d vertex1 = new Point3d(center[0] - width / 2, center[1], center[2]);
            Point3d vertex2 = new Point3d(center[0] - width / 2, center[1] + height - radius, center[2]);

            Point3d vertex3 = new Point3d(center[0] - width / 2 + radius, center[1] + height, center[2]);
            Point3d vertex4 = new Point3d(center[0] + width / 2 - radius, center[1] + height, center[2]);

            Point3d vertex5 = new Point3d(center[0] + width / 2, center[1], center[2]);
            Point3d vertex6 = new Point3d(center[0] + width / 2, center[1] + height - radius, center[2]);

            Arc semicircle1 = new Arc(center2, radius, Math.PI / 2, Math.PI);
            Arc semicircle2 = new Arc(center3, radius, 0, Math.PI / 2);

            Line line1 = new Line(vertex1, vertex2);
            Line line2 = new Line(vertex3, vertex4);
            Line line3 = new Line(vertex5, vertex6);
            Line line4 = new Line(vertex1, vertex5);

            // Создание региона из 2D-фигуры
            DBObjectCollection col = new DBObjectCollection();
            col.Add(line1);
            col.Add(line2);
            col.Add(line3);
            col.Add(line4);
            col.Add(semicircle1);
            col.Add(semicircle2);
            DBObjectCollection regions = Autodesk.AutoCAD.DatabaseServices.Region.CreateFromCurves(col);



            Region region = regions[0] as Region;
            return region;
        }
        public CirArcAndVol()
        {
            InitializeComponent();
            points = new List<Point3d>();
            heights = new List<double>();
            parts = new List<int>();
        }

        public void Test(double width, double height, double radius,  List<Point3d> centers,  List<double> HS, List<int> sects)
        {

            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = HostApplicationServices.WorkingDatabase;
            Transaction tr = db.TransactionManager.StartTransaction();
            Editor ed = doc.Editor;
            Random rand = new Random();
            double totVolume = 0;
            // Запрос ввода параметров
            int numPoints = centers.Count;
            int numPoints2 = HS.Count;
            using (tr)
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);
                List<Entity> sections = new List<Entity>();
                for (int i = 0; i < numPoints; i++)
                {
                    sections.Add(ArcFig(centers[i], width, radius, height));

                }
                double length = centers.Last().Z - centers.First().Z;
                Solid3d sol = new Solid3d { RecordHistory = true };
                LoftOptionsBuilder lob = new LoftOptionsBuilder { Ruled = true };
                sol.CreateLoftedSolid(sections.ToArray(), new Entity[0], null, lob.ToLoftOptions());
                Matrix3d rotation = Matrix3d.Rotation(Math.PI / 2, new Vector3d(1, 0, 0), centers[0]);
                Matrix3d trans1 = Matrix3d.Displacement(new Vector3d(width /2, length, 0));
                sol.TransformBy(rotation);
                sol.TransformBy(trans1);
                List<Solid3d> sols = new List<Solid3d>();
                List<Solid3d> endSols = new List<Solid3d>();
                sols.Add(sol);
                List<double> volumes = new List<double>();
                double h = height;
                Solid3d cp = sol.Clone() as Solid3d;
                for (int i = 0; i < numPoints2; i++)
                {

                    Solid3d copy = sols[i].Clone() as Solid3d;
                    Plane plane = new Plane(new Point3d(0, 0, h - HS[i]), new Vector3d(0, 0, 1));
                    copy.Slice(plane);
                    endSols.Add(copy);
                    Plane plane1 = new Plane(new Point3d(0, 0, h - HS[i]), new Vector3d(0, 0, -1));
                    cp.Slice(plane1);
                    sols.Add(cp);
                    volumes.Add(copy.MassProperties.Volume);
                    
                    h -= HS[i];
                }

                if (countofclick == 0)
                {
                    Color colorm = Color.FromColor(System.Drawing.Color.FromArgb(0, 0, 255));
                    double h2 = height;
                    Solid3d rect = new Solid3d();
                    rect.CreateBox(width * 4, length, height / 2);
                    rect.Color = colorm;
                    rect.TransformBy(Matrix3d.Displacement(new Vector3d(width / 2, length / 2, -height / 4)));
                    rect.TransformBy(Matrix3d.Displacement(new Vector3d(centers.First().X, centers.First().Y, centers.First().Z)));
                    btr.AppendEntity(rect);
                    tr.AddNewlyCreatedDBObject(rect, true);

                    Solid3d rect1 = new Solid3d();
                    rect1.CreateBox(width * 4, length, height / 2);
                    rect1.Color = colorm;
                    rect1.TransformBy(Matrix3d.Displacement(new Vector3d(width / 2, length / 2, height / 4 + HS.Sum())));
                    rect1.TransformBy(Matrix3d.Displacement(new Vector3d(centers.First().X, centers.First().Y, centers.First().Z)));
                    btr.AppendEntity(rect1);
                    tr.AddNewlyCreatedDBObject(rect1, true);


                    for (int i = 0; i < numPoints2; i++)
                    {
                        Solid3d cpy = sol.Clone() as Solid3d;
                        btr.AppendEntity(cpy);
                        tr.AddNewlyCreatedDBObject(cpy, true);
                        Solid3d rects = new Solid3d();
                        rects.CreateBox(width * 4, length, HS[i]);
                        Color color = Color.FromColor(System.Drawing.Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255)));
                        rects.Color = color;
                        rects.TransformBy(Matrix3d.Displacement(new Vector3d(width / 2, length / 2, HS[i] / 2 + h2 - HS[i])));
                        rects.TransformBy(Matrix3d.Displacement(new Vector3d(centers.First().X, centers.First().Y, centers.First().Z)));
                        btr.AppendEntity(rects);
                        tr.AddNewlyCreatedDBObject(rects, true);
                        rects.BooleanOperation(BooleanOperationType.BoolSubtract, cpy);
                        h2 -= HS[i];

                    }


                }
                
                
                
                for (int i = 0; i < numPoints2; i++)
                {
                    
                    if (sects.Contains(i))
                    {
                        totVolume += volumes[i];
                    }
                }
                OutputLabel.Text = ($"Объем выбранных частей - {totVolume}");
               
                tr.Commit();

            }
            
        }

        private void PointAddButton_Click(object sender, EventArgs e)
        {
            
            double x, y, z;
            if (double.TryParse(PointXBox.Text, out x) && double.TryParse(PointYBox.Text, out y) && double.TryParse(PointZBox.Text,out z)) {
                countofpoints++;
                points.Add(new Point3d(x, y, z)); 
                PointXBox.Clear();
                PointYBox.Clear();
                PointZBox.Clear();
                PointsLabel.Text = countofpoints.ToString();
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }

        private void heightAddButton_Click(object sender, EventArgs e)
        {
            double height;
            if (double.TryParse(HeightPartBox.Text, out height))
                {
                if (height <= 0)
                { 
                    MessageBox.Show("Значения должны быть положительными!"); 
                    HeightPartBox.Clear();
                }
                else
                {
                    countofboxes++;
                    heights.Add(height);
                    HeightPartBox.Clear();
                    checkedBox.Items.Add(countofboxes);
                }
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }

        private void CreateFigure_Click(object sender, EventArgs e)
        {
            double width, height, radius;
            if (double.TryParse(HeightBox.Text, out height) && double.TryParse(LengthBox.Text, out width) && double.TryParse(RadiusBox.Text, out radius) && points.Count>1)
            {
                if (width <= 0 || height <= 0 || radius < 0)
                { 
                    MessageBox.Show("Значения высоты, длины и радиуса должны быть положительными!"); 
                    HeightBox.Clear();
                    LengthBox.Clear();  
                    RadiusBox.Clear();  
                }
                else
                {
                    Test(width, height, radius, points, heights, parts);
                    countofclick++;
                }
                
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }

        private void checkedBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            int index = e.Index;
            bool isChecked = e.NewValue == CheckState.Checked;
            if (isChecked) { parts.Add(index); }
            else { parts.Remove(index); }
        }
        public void Output(string text)
        {
            OutputLabel.Text = "Объем выбранных частей - " + text;
        }
        
    }
}
