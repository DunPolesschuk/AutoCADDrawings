﻿namespace DrawFiguresForAutoCad
{
    partial class CirArcAndVol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.HeightBox = new System.Windows.Forms.TextBox();
            this.LengthBox = new System.Windows.Forms.TextBox();
            this.RadiusBox = new System.Windows.Forms.TextBox();
            this.PointXBox = new System.Windows.Forms.TextBox();
            this.PointYBox = new System.Windows.Forms.TextBox();
            this.PointZBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.PointAddButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.HeightPartBox = new System.Windows.Forms.TextBox();
            this.heightAddButton = new System.Windows.Forms.Button();
            this.checkedBox = new System.Windows.Forms.CheckedListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.CreateFigure = new System.Windows.Forms.Button();
            this.PointsLabel = new System.Windows.Forms.Label();
            this.OutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Высота:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Длина:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Радиус:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(91, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Точка:";
            // 
            // HeightBox
            // 
            this.HeightBox.Location = new System.Drawing.Point(121, 23);
            this.HeightBox.Name = "HeightBox";
            this.HeightBox.Size = new System.Drawing.Size(123, 26);
            this.HeightBox.TabIndex = 4;
            // 
            // LengthBox
            // 
            this.LengthBox.Location = new System.Drawing.Point(121, 58);
            this.LengthBox.Name = "LengthBox";
            this.LengthBox.Size = new System.Drawing.Size(123, 26);
            this.LengthBox.TabIndex = 5;
            // 
            // RadiusBox
            // 
            this.RadiusBox.Location = new System.Drawing.Point(121, 95);
            this.RadiusBox.Name = "RadiusBox";
            this.RadiusBox.Size = new System.Drawing.Size(123, 26);
            this.RadiusBox.TabIndex = 6;
            // 
            // PointXBox
            // 
            this.PointXBox.Location = new System.Drawing.Point(83, 203);
            this.PointXBox.Name = "PointXBox";
            this.PointXBox.Size = new System.Drawing.Size(65, 26);
            this.PointXBox.TabIndex = 7;
            // 
            // PointYBox
            // 
            this.PointYBox.Location = new System.Drawing.Point(83, 277);
            this.PointYBox.Name = "PointYBox";
            this.PointYBox.Size = new System.Drawing.Size(65, 26);
            this.PointYBox.TabIndex = 8;
            // 
            // PointZBox
            // 
            this.PointZBox.Location = new System.Drawing.Point(83, 242);
            this.PointZBox.Name = "PointZBox";
            this.PointZBox.Size = new System.Drawing.Size(65, 26);
            this.PointZBox.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(42, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "X:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(42, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Y:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(43, 280);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Z:";
            // 
            // PointAddButton
            // 
            this.PointAddButton.Location = new System.Drawing.Point(47, 321);
            this.PointAddButton.Name = "PointAddButton";
            this.PointAddButton.Size = new System.Drawing.Size(92, 61);
            this.PointAddButton.TabIndex = 13;
            this.PointAddButton.Text = "Добавить";
            this.PointAddButton.UseVisualStyleBackColor = true;
            this.PointAddButton.Click += new System.EventHandler(this.PointAddButton_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(298, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(185, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "Введите высоту части:";
            // 
            // HeightPartBox
            // 
            this.HeightPartBox.Location = new System.Drawing.Point(508, 26);
            this.HeightPartBox.Name = "HeightPartBox";
            this.HeightPartBox.Size = new System.Drawing.Size(100, 26);
            this.HeightPartBox.TabIndex = 16;
            // 
            // heightAddButton
            // 
            this.heightAddButton.Location = new System.Drawing.Point(353, 66);
            this.heightAddButton.Name = "heightAddButton";
            this.heightAddButton.Size = new System.Drawing.Size(101, 55);
            this.heightAddButton.TabIndex = 17;
            this.heightAddButton.Text = "Добавить";
            this.heightAddButton.UseVisualStyleBackColor = true;
            this.heightAddButton.Click += new System.EventHandler(this.heightAddButton_Click);
            // 
            // checkedBox
            // 
            this.checkedBox.FormattingEnabled = true;
            this.checkedBox.Location = new System.Drawing.Point(302, 206);
            this.checkedBox.Name = "checkedBox";
            this.checkedBox.Size = new System.Drawing.Size(178, 188);
            this.checkedBox.TabIndex = 18;
            this.checkedBox.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedBox_ItemCheck);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(298, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(193, 20);
            this.label10.TabIndex = 19;
            this.label10.Text = "Выберите нужные части";
            // 
            // CreateFigure
            // 
            this.CreateFigure.Location = new System.Drawing.Point(190, 427);
            this.CreateFigure.Name = "CreateFigure";
            this.CreateFigure.Size = new System.Drawing.Size(409, 104);
            this.CreateFigure.TabIndex = 20;
            this.CreateFigure.Text = "Построить";
            this.CreateFigure.UseVisualStyleBackColor = true;
            this.CreateFigure.Click += new System.EventHandler(this.CreateFigure_Click);
            // 
            // PointsLabel
            // 
            this.PointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PointsLabel.Location = new System.Drawing.Point(169, 229);
            this.PointsLabel.Name = "PointsLabel";
            this.PointsLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.PointsLabel.Size = new System.Drawing.Size(60, 60);
            this.PointsLabel.TabIndex = 22;
            this.PointsLabel.Text = "0";
            this.PointsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OutputLabel
            // 
            this.OutputLabel.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.OutputLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OutputLabel.Location = new System.Drawing.Point(539, 98);
            this.OutputLabel.Name = "OutputLabel";
            this.OutputLabel.Size = new System.Drawing.Size(280, 294);
            this.OutputLabel.TabIndex = 23;
            // 
            // CirArcAndVol
            // 
            this.ClientSize = new System.Drawing.Size(831, 557);
            this.Controls.Add(this.OutputLabel);
            this.Controls.Add(this.PointsLabel);
            this.Controls.Add(this.CreateFigure);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.checkedBox);
            this.Controls.Add(this.heightAddButton);
            this.Controls.Add(this.HeightPartBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.PointAddButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.PointZBox);
            this.Controls.Add(this.PointYBox);
            this.Controls.Add(this.PointXBox);
            this.Controls.Add(this.RadiusBox);
            this.Controls.Add(this.LengthBox);
            this.Controls.Add(this.HeightBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "CirArcAndVol";
            this.Text = "Drawing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox HeightBox;
        private System.Windows.Forms.TextBox LengthBox;
        private System.Windows.Forms.TextBox RadiusBox;
        private System.Windows.Forms.TextBox PointXBox;
        private System.Windows.Forms.TextBox PointYBox;
        private System.Windows.Forms.TextBox PointZBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button PointAddButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox HeightPartBox;
        private System.Windows.Forms.Button heightAddButton;
        private System.Windows.Forms.CheckedListBox checkedBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button CreateFigure;
        private System.Windows.Forms.Label PointsLabel;
        private System.Windows.Forms.Label OutputLabel;
    }
}