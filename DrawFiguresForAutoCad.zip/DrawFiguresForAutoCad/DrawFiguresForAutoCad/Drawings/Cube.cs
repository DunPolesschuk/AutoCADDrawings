﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media.Media3D;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.PlottingServices;
using Autodesk.AutoCAD.Runtime;
namespace DrawFiguresForAutoCad
{
    public partial class Cube : Form
    {
        public Cube()
        {
            InitializeComponent();
        }
        public void DrawCube(Point3d center, double sideLength)
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;

            

            // Получаем текущую базу данных и начинаем транзакцию
            var db = doc.Database;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                // Открываем таблицу блоков для чтения
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);

                // Открываем запись таблицы блоков модели для записи
                var btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                // Создаем новый куб с заданными параметрами
                var cube = new Solid3d();
                cube.CreateBox(sideLength, sideLength, sideLength);
                cube.TransformBy(Matrix3d.Displacement(center - Point3d.Origin));

                // Добавляем новый куб в запись таблицы блоков и транзакцию
                btr.AppendEntity(cube);
                tr.AddNewlyCreatedDBObject(cube, true);

                // Завершаем транзакцию
                tr.Commit();
            }
        }

        private void CreateBut_Click(object sender, EventArgs e)
        {
            double x, y, z, length;
            if (double.TryParse(XBox.Text, out x) && double.TryParse(YBox.Text, out y) && double.TryParse(ZBox.Text, out z) && double.TryParse(LengthBox.Text, out length))
            {
                if (length <= 0)
                {
                    MessageBox.Show("Значение длины должно быть положительными!");
                    LengthBox.Clear();
                }
                else
                {
                    Point3d center = new Point3d(x, y, z);
                    LengthBox.Clear();
                    XBox.Clear();
                    YBox.Clear();
                    ZBox.Clear();
                    DrawCube(center, length);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }
    }
}
