﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media.Media3D;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.PlottingServices;
using Autodesk.AutoCAD.Runtime;
namespace DrawFiguresForAutoCad
{
    public partial class Sphere : Form
    {
        public Sphere()
        {
            InitializeComponent();
        }
        public void DrawSphere(Point3d center, double radius)
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;

            

            // Получаем текущую базу данных и начинаем транзакцию
            var db = doc.Database;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                // Открываем таблицу блоков для чтения
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);

                // Открываем запись таблицы блоков модели для записи
                var btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                // Создаем новую сферу с заданными параметрами
                var sphere = new Solid3d();
                sphere.CreateSphere(radius);
                sphere.TransformBy(Matrix3d.Displacement(center - Point3d.Origin));

                // Добавляем новую сферу в запись таблицы блоков и транзакцию
                btr.AppendEntity(sphere);
                tr.AddNewlyCreatedDBObject(sphere, true);

                // Завершаем транзакцию
                tr.Commit();
            }
        }

        private void CreateBut_Click(object sender, EventArgs e)
        {
            double x, y, z, radius;
            if (double.TryParse(XBox.Text, out x) && double.TryParse(YBox.Text, out y) && double.TryParse(ZBox.Text, out z) && double.TryParse(RadiusBox.Text, out radius))
            {
                if (radius <= 0)
                { 
                    MessageBox.Show("Значение радиуса должно быть положительными!");
                    RadiusBox.Clear();
                }
                else
                {
                    Point3d center = new Point3d(x, y, z);
                    RadiusBox.Clear();
                    XBox.Clear();
                    YBox.Clear();
                    ZBox.Clear();
                    DrawSphere(center, radius);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }

        
    }
}
