﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.PlottingServices;
using Autodesk.AutoCAD.Runtime;
namespace DrawFiguresForAutoCad
{
    public partial class Cylinder : Form
    {
        public Cylinder()
        {
            InitializeComponent();
        }
        public void DrawCylinder(Point3d baseCenter, double baseRadius, double height)
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            var db = doc.Database;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                var btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                

                

                Solid3d cylinder = new Solid3d();
               
                    cylinder.CreateFrustum(height, baseRadius, baseRadius, baseRadius);
                    cylinder.TransformBy(Matrix3d.Displacement(baseCenter - Point3d.Origin + new Vector3d(0, 0, height / 2)));
                

                btr.AppendEntity(cylinder);
                tr.AddNewlyCreatedDBObject(cylinder, true);

                tr.Commit();
            }
        }

        private void CreateBut_Click(object sender, EventArgs e)
        {
            double x, y, z, radius, height;
            if (double.TryParse(XBox.Text, out x) && double.TryParse(YBox.Text, out y) && double.TryParse(ZBox.Text, out z) && double.TryParse(RadiusBox.Text, out radius) && double.TryParse(HeightBox.Text, out height))
            {
                if (height <= 0 || radius < 0)
                {
                    MessageBox.Show("Значения высоты и радиуса должны быть положительными!");
                    HeightBox.Clear();
                    RadiusBox.Clear();
                }
                else
                {
                    Point3d center = new Point3d(x, y, z);
                    RadiusBox.Clear();
                    XBox.Clear();
                    YBox.Clear();
                    ZBox.Clear();
                    DrawCylinder(center, radius, height);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }

        
    }
}
