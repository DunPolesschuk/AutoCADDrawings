﻿using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.AutoCAD.Colors;
using System.Windows.Forms;
using Region = Autodesk.AutoCAD.DatabaseServices.Region;
using Color = Autodesk.AutoCAD.Colors.Color;
using static Autodesk.AutoCAD.Internal.Forms.ExListView;
using System.Windows.Media.Media3D;

namespace DrawFiguresForAutoCad
{
    public partial class CirArcByPoints : Form
    {
        List<Point3d> points;
        
        
        int countofpoints = 0;
        
        public Region ArcFig(Point3d center, double width, double radius, double height)
        {
            Point3d center2 = new Point3d(center[0] - width / 2 + radius, center[1] + height - radius, center[2]);
            Point3d center3 = new Point3d(center[0] + width / 2 - radius, center[1] + height - radius, center[2]);

            Point3d vertex1 = new Point3d(center[0] - width / 2, center[1], center[2]);
            Point3d vertex2 = new Point3d(center[0] - width / 2, center[1] + height - radius, center[2]);

            Point3d vertex3 = new Point3d(center[0] - width / 2 + radius, center[1] + height, center[2]);
            Point3d vertex4 = new Point3d(center[0] + width / 2 - radius, center[1] + height, center[2]);

            Point3d vertex5 = new Point3d(center[0] + width / 2, center[1], center[2]);
            Point3d vertex6 = new Point3d(center[0] + width / 2, center[1] + height - radius, center[2]);

            Arc semicircle1 = new Arc(center2, radius, Math.PI / 2, Math.PI);
            Arc semicircle2 = new Arc(center3, radius, 0, Math.PI / 2);

            Line line1 = new Line(vertex1, vertex2);
            Line line2 = new Line(vertex3, vertex4);
            Line line3 = new Line(vertex5, vertex6);
            Line line4 = new Line(vertex1, vertex5);

            // Создание региона из 2D-фигуры
            DBObjectCollection col = new DBObjectCollection();
            col.Add(line1);
            col.Add(line2);
            col.Add(line3);
            col.Add(line4);
            col.Add(semicircle1);
            col.Add(semicircle2);
            DBObjectCollection regions = Autodesk.AutoCAD.DatabaseServices.Region.CreateFromCurves(col);



            Region region = regions[0] as Region;
            return region;
        }
        public CirArcByPoints()
        {
            InitializeComponent();
            points = new List<Point3d>();
            
        }

        public void CreateLoftedCircularArc(double width, double height, double radius, List<Point3d> centers, Vector3d direction, double AngleValue)
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = HostApplicationServices.WorkingDatabase;
            Transaction tr = db.TransactionManager.StartTransaction();
            Editor ed = doc.Editor;
            // Запрос ввода параметров
            int numPoints = centers.Count;


            using (tr)
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);
                List<Entity> sections = new List<Entity>();
                for (int i = 0; i < numPoints; i++)
                {
                    sections.Add(ArcFig(centers[i], width, radius, height));

                }
                Point3d center = centers[0];
                Solid3d sol = new Solid3d { RecordHistory = true };
                LoftOptionsBuilder lob = new LoftOptionsBuilder { Ruled = true };
                sol.CreateLoftedSolid(sections.ToArray(), new Entity[0], null, lob.ToLoftOptions());
                Matrix3d rotation = Matrix3d.Rotation(AngleValue / 57.296, direction, center);
                
                sol.TransformBy(rotation);
                sol.TransformBy(Matrix3d.Displacement(new Vector3d(0, centers.Last().Z - centers[0].Z, 0)));

                btr.AppendEntity(sol);
                tr.AddNewlyCreatedDBObject(sol, true);




                tr.Commit();
            }
        }

        private void PointAddButton_Click(object sender, EventArgs e)
        {
            
            double x, y, z;
            if (double.TryParse(PointXBox.Text, out x) && double.TryParse(PointYBox.Text, out y) && double.TryParse(PointZBox.Text,out z)) {
                countofpoints++;
                points.Add(new Point3d(x, y, z)); 
                PointXBox.Clear();
                PointYBox.Clear();
                PointZBox.Clear();
                PointsLabel.Text = countofpoints.ToString();
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }

       
        private void CreateFigure_Click(object sender, EventArgs e)
        {
            
            double vx, vy, vz, width, height, radius, angle;
            if (double.TryParse(HeightBox.Text, out height) && double.TryParse(LengthBox.Text, out width) && double.TryParse(RadiusBox.Text, out radius) && points.Count>1 &&
                double.TryParse(VXBox.Text, out vx) && double.TryParse(VYBox.Text, out vy) && double.TryParse(VZBox.Text, out vz) && double.TryParse(AngleBox.Text, out angle))
            {
                if (width <= 0 || height <= 0 || radius < 0)
                { MessageBox.Show("Значения высоты, длины и радиуса должны быть положительными!"); 
                    HeightBox.Clear();
                    LengthBox.Clear();
                    RadiusBox.Clear();
                }
                else
                {
                    Vector3d dir = new Vector3d(vx, vy, vz);
                    CreateLoftedCircularArc(width, height, radius, points, dir, angle);
                    this.Close();
                }
                     
                
                
            }
            else
            {
                MessageBox.Show("Введите все данные корректно");
            }
        }

        
        
    }
}
