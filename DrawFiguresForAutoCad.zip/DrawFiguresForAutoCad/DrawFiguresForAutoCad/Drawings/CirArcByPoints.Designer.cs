﻿namespace DrawFiguresForAutoCad
{
    partial class CirArcByPoints
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.HeightBox = new System.Windows.Forms.TextBox();
            this.LengthBox = new System.Windows.Forms.TextBox();
            this.RadiusBox = new System.Windows.Forms.TextBox();
            this.PointXBox = new System.Windows.Forms.TextBox();
            this.PointYBox = new System.Windows.Forms.TextBox();
            this.PointZBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.PointAddButton = new System.Windows.Forms.Button();
            this.CreateFigure = new System.Windows.Forms.Button();
            this.PointsLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.AngleBox = new System.Windows.Forms.TextBox();
            this.VXBox = new System.Windows.Forms.TextBox();
            this.VYBox = new System.Windows.Forms.TextBox();
            this.VZBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Высота:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Длина:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Радиус:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(89, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Точка:";
            // 
            // HeightBox
            // 
            this.HeightBox.Location = new System.Drawing.Point(121, 33);
            this.HeightBox.Name = "HeightBox";
            this.HeightBox.Size = new System.Drawing.Size(123, 26);
            this.HeightBox.TabIndex = 4;
            // 
            // LengthBox
            // 
            this.LengthBox.Location = new System.Drawing.Point(121, 75);
            this.LengthBox.Name = "LengthBox";
            this.LengthBox.Size = new System.Drawing.Size(123, 26);
            this.LengthBox.TabIndex = 5;
            // 
            // RadiusBox
            // 
            this.RadiusBox.Location = new System.Drawing.Point(121, 111);
            this.RadiusBox.Name = "RadiusBox";
            this.RadiusBox.Size = new System.Drawing.Size(123, 26);
            this.RadiusBox.TabIndex = 6;
            // 
            // PointXBox
            // 
            this.PointXBox.Location = new System.Drawing.Point(93, 208);
            this.PointXBox.Name = "PointXBox";
            this.PointXBox.Size = new System.Drawing.Size(73, 26);
            this.PointXBox.TabIndex = 7;
            // 
            // PointYBox
            // 
            this.PointYBox.Location = new System.Drawing.Point(93, 245);
            this.PointYBox.Name = "PointYBox";
            this.PointYBox.Size = new System.Drawing.Size(73, 26);
            this.PointYBox.TabIndex = 8;
            // 
            // PointZBox
            // 
            this.PointZBox.Location = new System.Drawing.Point(93, 284);
            this.PointZBox.Name = "PointZBox";
            this.PointZBox.Size = new System.Drawing.Size(73, 26);
            this.PointZBox.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(55, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "X:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(55, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Y:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(56, 287);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Z:";
            // 
            // PointAddButton
            // 
            this.PointAddButton.Location = new System.Drawing.Point(60, 331);
            this.PointAddButton.Name = "PointAddButton";
            this.PointAddButton.Size = new System.Drawing.Size(92, 40);
            this.PointAddButton.TabIndex = 13;
            this.PointAddButton.Text = "Добавить";
            this.PointAddButton.UseVisualStyleBackColor = true;
            this.PointAddButton.Click += new System.EventHandler(this.PointAddButton_Click);
            // 
            // CreateFigure
            // 
            this.CreateFigure.Location = new System.Drawing.Point(302, 236);
            this.CreateFigure.Name = "CreateFigure";
            this.CreateFigure.Size = new System.Drawing.Size(187, 45);
            this.CreateFigure.TabIndex = 20;
            this.CreateFigure.Text = "Построить";
            this.CreateFigure.UseVisualStyleBackColor = true;
            this.CreateFigure.Click += new System.EventHandler(this.CreateFigure_Click);
            // 
            // PointsLabel
            // 
            this.PointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PointsLabel.Location = new System.Drawing.Point(184, 227);
            this.PointsLabel.Name = "PointsLabel";
            this.PointsLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.PointsLabel.Size = new System.Drawing.Size(60, 60);
            this.PointsLabel.TabIndex = 22;
            this.PointsLabel.Text = "0";
            this.PointsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(327, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 20);
            this.label8.TabIndex = 23;
            this.label8.Text = "Направление:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(256, 185);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 20);
            this.label9.TabIndex = 24;
            this.label9.Text = "Угол поворота:";
            // 
            // AngleBox
            // 
            this.AngleBox.Location = new System.Drawing.Point(390, 182);
            this.AngleBox.Name = "AngleBox";
            this.AngleBox.Size = new System.Drawing.Size(63, 26);
            this.AngleBox.TabIndex = 26;
            // 
            // VXBox
            // 
            this.VXBox.Location = new System.Drawing.Point(377, 66);
            this.VXBox.Name = "VXBox";
            this.VXBox.Size = new System.Drawing.Size(76, 26);
            this.VXBox.TabIndex = 27;
            // 
            // VYBox
            // 
            this.VYBox.Location = new System.Drawing.Point(377, 103);
            this.VYBox.Name = "VYBox";
            this.VYBox.Size = new System.Drawing.Size(76, 26);
            this.VYBox.TabIndex = 28;
            // 
            // VZBox
            // 
            this.VZBox.Location = new System.Drawing.Point(377, 139);
            this.VZBox.Name = "VZBox";
            this.VZBox.Size = new System.Drawing.Size(76, 26);
            this.VZBox.TabIndex = 29;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(327, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 20);
            this.label10.TabIndex = 30;
            this.label10.Text = "X:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(326, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 20);
            this.label11.TabIndex = 31;
            this.label11.Text = "Y:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(327, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 20);
            this.label12.TabIndex = 32;
            this.label12.Text = "Z:";
            // 
            // CirArcByPoints
            // 
            this.ClientSize = new System.Drawing.Size(589, 409);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.VZBox);
            this.Controls.Add(this.VYBox);
            this.Controls.Add(this.VXBox);
            this.Controls.Add(this.AngleBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.PointsLabel);
            this.Controls.Add(this.CreateFigure);
            this.Controls.Add(this.PointAddButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.PointZBox);
            this.Controls.Add(this.PointYBox);
            this.Controls.Add(this.PointXBox);
            this.Controls.Add(this.RadiusBox);
            this.Controls.Add(this.LengthBox);
            this.Controls.Add(this.HeightBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "CirArcByPoints";
            this.Text = "Drawing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox HeightBox;
        private System.Windows.Forms.TextBox LengthBox;
        private System.Windows.Forms.TextBox RadiusBox;
        private System.Windows.Forms.TextBox PointXBox;
        private System.Windows.Forms.TextBox PointYBox;
        private System.Windows.Forms.TextBox PointZBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button PointAddButton;
        private System.Windows.Forms.Button CreateFigure;
        private System.Windows.Forms.Label PointsLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox AngleBox;
        private System.Windows.Forms.TextBox VXBox;
        private System.Windows.Forms.TextBox VYBox;
        private System.Windows.Forms.TextBox VZBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}