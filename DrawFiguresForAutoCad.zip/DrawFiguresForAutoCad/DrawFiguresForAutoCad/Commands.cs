﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.PlottingServices;
using Autodesk.AutoCAD.Runtime;
using Region = Autodesk.AutoCAD.DatabaseServices.Region;
using Surface = Autodesk.AutoCAD.DatabaseServices.Surface;

namespace DrawFiguresForAutoCad
{
    public class Commands
    {
        [CommandMethod("Drawings")]
        public void ShowForm()
        {
            MainForm form = new MainForm();
            Application.ShowModalDialog(form);
        }

    }
}
